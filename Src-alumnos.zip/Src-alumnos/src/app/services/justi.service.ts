import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class JustiService {
  private usuariosPath = 'http://localhost:3000/usuarios'; 

  constructor(private http: HttpClient) {}

  async getJustificacionesUsuarios(): Promise<any[]> {
    try {
      const usuarios = await this.http.get<any[]>(this.usuariosPath).toPromise();


      const justificacionesUsuarios = (usuarios || [])
        .map((u) => u.justificaciones || []) 
        .reduce((acc, curr) => acc.concat(curr), []);

      console.log('Justificaciones de usuarios cargadas:', justificacionesUsuarios);
      return justificacionesUsuarios;
    } catch (error) {
      console.error('Error al obtener las justificaciones de usuarios:', error);
      return [];
    }
  }
}
