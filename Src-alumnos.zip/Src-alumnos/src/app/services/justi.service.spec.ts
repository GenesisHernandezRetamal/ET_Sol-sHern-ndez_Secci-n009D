import { TestBed } from '@angular/core/testing';

import { JustiService } from './justi.service';

describe('JustiService', () => {
  let service: JustiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(JustiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
