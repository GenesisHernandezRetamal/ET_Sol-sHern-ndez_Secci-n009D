import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map } from 'rxjs/operators'; 
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { BehaviorSubject } from 'rxjs';


@Injectable({
  providedIn: 'root',
})
export class UsuariosService {
  private usuarioLogueado: any = null;

    private usuariosUrl = 'http://localhost:3000/usuarios'; 
    private usuarios: any[] = [];
    private usuariosSubject = new BehaviorSubject<any[]>([]);
    private localStorageKey = 'usuarios';
  
  private apiUrl = 'http://localhost:3000/usuarios'; 

  constructor(private http: HttpClient) {

  }

  
  getUsuario() {
    return this.usuariosSubject.asObservable();
  }

  actualizarUsuario(id: string, nuevosDatos: any) {
    const index = this.usuarios.findIndex((usuario) => usuario.id === id);
    if (index !== -1) {
      this.usuarios[index] = { ...this.usuarios[index], ...nuevosDatos };
      this.usuariosSubject.next(this.usuarios);
      this.guardarJSON();
    }
  }

  guardarJSON() {
    localStorage.setItem('usuarios', JSON.stringify(this.usuarios));
    console.log('Datos guardados en localStorage:', this.usuarios);
  }
  


  getUsuarios(): Observable<any> {
    return this.http.get(this.apiUrl);
  }

  getUsuarioById(id: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/${id}`);
  }


  getUsuarioByIdFiltered(id: string): Observable<any> {
    return this.http.get<any[]>(this.apiUrl).pipe(
      map((usuarios) => usuarios.find((usuario) => usuario.id === id)) 
    );
  }

  getUsuarioByIdd(id: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${id}`);
  }
  

  // Obtener todos los usuarios
  getUsuarioss(): Observable<any> {
    return this.http.get(this.apiUrl);
  }

  getUsuarioByyId(id: string) {
    return this.http.get(`http://localhost:3000/usuarios/${id}`);
  }
  

 
  updateUsuario(id: string, updatedData: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/${id}`, updatedData);
  }

  putUsuarios(usuario: any): Observable<any> {
    if (!usuario.id) {
      console.error('El usuario debe tener un ID para actualizar.');
      return of(null);
    }

    return this.http.put(`http://localhost:3000/usuarios/${usuario.id}`, usuario);
  }
  
}
