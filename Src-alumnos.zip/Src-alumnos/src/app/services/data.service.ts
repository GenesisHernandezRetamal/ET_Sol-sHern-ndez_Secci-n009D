import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

interface Asignatura {
  id: string;
  nombre: string;
}

@Injectable({
  providedIn: 'root',
})
export class DataService {
  private jsonPath = 'http://localhost:3000/profes'; 
  private usuariosPath = 'http://localhost:3000/usuarios';
  

  constructor(private http: HttpClient) {}

 
  async getUsuarios(): Promise<any[]> {
    try {
      const endpoint = `${this.usuariosPath}`;
      const response = await this.http.get<any[]>(endpoint).toPromise();
      console.log('Usuarios cargados:', response);
      return response || [];
    } catch (error) {
      console.error('Error al obtener los usuarios:', error);
      return [];
    }
  }

  
  async getProfesores(): Promise<any[]> {
    try {
      const endpoint = `${this.jsonPath}`;
      const response = await this.http.get<any[]>(endpoint).toPromise();
      console.log('Profesores cargados:', response);
      return response || [];
    } catch (error) {
      console.error('Error al obtener los profesores:', error);
      return [];
    }
  }

 
  async obtenerJustificacionesDelUsuario(): Promise<any[]> {
    try {

      const usuarios = await this.getUsuarios();
      

      const usuarioId = localStorage.getItem('usuarioId'); 


      const usuario = usuarios.find(u => u.id === usuarioId);

      if (usuario) {

        return usuario.justificaciones || [];
      } else {
        throw new Error('Usuario no encontrado');
      }
    } catch (error) {
      console.error('Error al obtener las justificaciones:', error);
      throw error;
    }
  }

  async agregarJustificacion(
    idUsuario: string,
    idProfesor: string,
    idAsignatura: string,
    motivo: string
  ) {
    try {
      const usuarios = await this.getUsuarios(); 
      const usuario = usuarios.find(u => u.id === idUsuario);
      const profesores = await this.getProfesores(); 
      const profesor = profesores.find(p => p.id === idProfesor); 

      if (usuario && profesor) {
     
        const asignatura = profesor.asignaturas.find((a: Asignatura) => a.id === idAsignatura);

        if (asignatura) {

          const nuevaJustificacion = {
            idJustificacion: Date.now(), 
            idUsuario,
            idProfesor,
            asignatura: {
              idAsignatura,
              nombre: asignatura.nombre, 
              fecha: new Date().toISOString(),
              profesor: profesor.username, 
              qrData: 'QR de ejemplo', 
            },
            fecha: new Date().toISOString(),
            motivo,
            comentarioDocente: '',
          };

        
          usuario.justificaciones.push(nuevaJustificacion);

         
          if (!profesor.justificaciones) {
            profesor.justificaciones = []; 
          }
          profesor.justificaciones.push(nuevaJustificacion);

          const endpointUsuario = `${this.usuariosPath}/${idUsuario}`;
          const endpointProfesor = `${this.jsonPath}/${idProfesor}`;


          const [responseUsuario, responseProfesor] = await Promise.all([ 
            this.http.put(endpointUsuario, usuario).toPromise(),
            this.http.put(endpointProfesor, profesor).toPromise(),
          ]);

          console.log('Justificación agregada a usuario y profesor:', responseUsuario, responseProfesor);
          return { usuario: responseUsuario, profesor: responseProfesor };
        } else {
          throw new Error('Asignatura no encontrada');
        }
      } else {
        throw new Error('Usuario o profesor no encontrados');
      }
    } catch (error) {
      console.error('Error al agregar la justificación:', error);
      throw error;
    }
  }

 

 
  
}  
