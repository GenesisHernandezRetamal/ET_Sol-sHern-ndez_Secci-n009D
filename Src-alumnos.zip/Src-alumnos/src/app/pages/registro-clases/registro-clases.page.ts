import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/services/auth.service';
import { Users } from 'src/interfaces/users';

@Component({
  selector: 'app-registro-clases',
  templateUrl: './registro-clases.page.html',
  styleUrls: ['./registro-clases.page.scss'],
})
export class RegistroClasesPage implements OnInit {

  usuario: Users | null = null;
  clasesRegistradas: any[] = [];
  qrData: string | null = null;

  constructor(private authService: AuthserviceService) { }

  ngOnInit(): void {
    const username = sessionStorage.getItem('username');
    
    if (username) {
      this.authService.GetUserByUsername(username).subscribe(
        (usuarios) => {
          const usuarioLogueado = usuarios.find(u => u.username === username);
          if (usuarioLogueado) {
            this.usuario = usuarioLogueado;
            this.clasesRegistradas = usuarioLogueado.clasesRegistradas;
          }
        },
        (error) => {
          console.error('Error al obtener el usuario:', error);
        }
      );
    }
  }


  generarQR(clase: any): void {
    console.log('Datos de la clase seleccionada:', clase);
    console.log('Datos del usuario logueado:', this.usuario);


    
    this.qrData = `${clase.nombre} ${clase.profesor} ${this.usuario?.email} ${this.usuario?.rut}`;


    this.guardarQR(clase);
  }


  guardarQR(clase: any): void {

    
    const claseIndex = this.clasesRegistradas.findIndex(c => c.idAsignatura === clase.idAsignatura);
    if (claseIndex !== -1) {
      this.clasesRegistradas[claseIndex].qrData = this.qrData;

      if (this.usuario) {
        this.usuario.clasesRegistradas = this.clasesRegistradas;
 
        this.authService.updateUser(this.usuario).subscribe(
          (response) => {
            console.log('Usuario actualizado con el QR');
          },
          (error) => {
            console.error('Error al actualizar usuario:', error);
          }
        );
      }
    }
  }
}
