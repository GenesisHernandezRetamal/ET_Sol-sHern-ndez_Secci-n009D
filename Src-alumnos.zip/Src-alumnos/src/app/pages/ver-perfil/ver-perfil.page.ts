import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-ver-perfil',
  templateUrl: './ver-perfil.page.html',
  styleUrls: ['./ver-perfil.page.scss'],
})
export class VerPerfilPage implements OnInit {
  usuario: any;

  constructor(private authservice: AuthserviceService) {}

  ngOnInit() {

    this.usuario = this.authservice.getCurrentUser();
  }
  
}
