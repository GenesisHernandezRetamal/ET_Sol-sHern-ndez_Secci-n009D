import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-cambiar-contra',
  templateUrl: './cambiar-contra.page.html',
  styleUrls: ['./cambiar-contra.page.scss'],
})
export class CambiarContraPage {
  email: string = '';
  resetToken: string = '';
  newPassword: string = '';
  showTokenInput: boolean = false;
  usuarios: any[] = []; // Lista de usuarios cargada desde el archivo JSON

  constructor(private http: HttpClient, private toastCtrl: ToastController) {}

  async presentToast(message: string, color: string = 'primary') {
    const toast = await this.toastCtrl.create({
      message,
      duration: 3000,
      color,
    });
    toast.present();
  }

  cargarUsuarios() {
    this.http.get('http://localhost:3000/usuarios').subscribe({
      next: (data: any) => {
        console.log('Respuesta recibida:', data);
  
        this.usuarios = data || [];
        console.log('Datos cargados:', this.usuarios); 
      },
      error: (err) => {
        console.error('Error al cargar usuarios:', err);
        this.presentToast('Error al cargar los datos. Inténtalo de nuevo.', 'danger');
        this.usuarios = []; 
      },
    });
  }

  onSubmit() {
    if (!this.usuarios || this.usuarios.length === 0) {
      this.presentToast('Los datos aún no se han cargado. Intenta más tarde.', 'danger');
      return;
    }
    console.log('Correo ingresado:', this.email); 
    console.log('Usuarios cargados:', this.usuarios); 

    const user = this.usuarios.find((u) => u.email.toLowerCase() === this.email.toLowerCase()); 
    
    if (user) {
      console.log('Usuario encontrado:', user);
      this.presentToast('Correo encontrado. Introduce el código enviado.');
      this.showTokenInput = true; 
    } else {
      console.log('Correo no encontrado');
      this.presentToast('Correo no encontrado.', 'danger');
    }
  }


  resetPassword() {
    const user = this.usuarios.find((u) => u.email === this.email);

    if (user) {
      user.password = this.newPassword;
      this.http.put(`http://localhost:3000/usuarios/${user.id}`, user).subscribe({
        next: (response) => {
          console.log('Contraseña actualizada en el servidor:', response);
          this.presentToast('Contraseña actualizada exitosamente.', 'success');
        },
        error: (err) => {
          console.error('Error al actualizar la contraseña:', err);
          this.presentToast('Error al actualizar la contraseña en el servidor.', 'danger');
        }
      });

      this.showTokenInput = false;
      this.email = '';
      this.resetToken = '';
      this.newPassword = '';
    } else {
      this.presentToast('No se pudo actualizar la contraseña.', 'danger');
    }
  }


  ionViewDidEnter() {
    this.cargarUsuarios();
  }
}
