import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { InicioSesPageRoutingModule } from './inicio-ses-routing.module';

import { InicioSesPage } from './inicio-ses.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReactiveFormsModule,
    InicioSesPageRoutingModule
  ],
  declarations: [InicioSesPage]
})
export class InicioSesPageModule {}
