import { ComponentFixture, TestBed } from '@angular/core/testing';
import { InicioSesPage } from './inicio-ses.page';

describe('InicioSesPage', () => {
  let component: InicioSesPage;
  let fixture: ComponentFixture<InicioSesPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(InicioSesPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
