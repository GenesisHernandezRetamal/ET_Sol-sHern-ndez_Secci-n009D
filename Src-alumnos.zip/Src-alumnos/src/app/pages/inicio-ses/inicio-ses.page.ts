import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthserviceService } from 'src/app/services/auth.service';
import { AlertController, ToastController } from '@ionic/angular';

@Component({
  selector: 'app-inicio-ses',
  templateUrl: './inicio-ses.page.html',
  styleUrls: ['./inicio-ses.page.scss'],
})
export class InicioSesPage implements OnInit {

  loginForm: FormGroup;

  constructor(
    private authservice: AuthserviceService,
    private router: Router,
    private toast: ToastController,
    private alertcontroller: AlertController,
    private builder: FormBuilder
  ) {
    this.loginForm = this.builder.group({
      'username': new FormControl("", [Validators.required, Validators.minLength(6)]),
      'password': new FormControl("", [Validators.required, Validators.minLength(8)]),
    });
  }

  ngOnInit() {
    if (this.authservice.IsLoggedIn()) {
      this.showToast('Ya has iniciado sesión.');
      this.router.navigate(['/inicio']);  
    }
  }

  login() {
    if (!this.loginForm.valid) {
      return;
    }
    const { username, password } = this.loginForm.value;

    this.authservice.login(username, password).subscribe({
      next: () => {
        this.showToast(`¡Bienvenido, ${username}!`);
        this.router.navigate(['/inicio']).then(() => {
          window.location.reload(); // Recarga la página después de la navegación
        });
      },
      error: (err) => {
        this.showErrorAlert('Credenciales incorrectas o usuario no encontrado.');
        this.loginForm.reset();
      }
    });
  }

  async showToast(message: string) {
    const toast = await this.toast.create({
      message: message,
      duration: 3000,
    });
    toast.present();
  }

  async showErrorAlert(message: string) {
    const alert = await this.alertcontroller.create({
      header: 'Error',
      message: message,
      buttons: ['OK'],
    });
    alert.present();
  }

  registrar() {
    this.router.navigate(['/crear-usuario']);
  }
}
