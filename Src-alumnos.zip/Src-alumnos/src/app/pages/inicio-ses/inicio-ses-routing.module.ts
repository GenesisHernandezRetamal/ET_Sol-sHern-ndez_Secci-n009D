import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { InicioSesPage } from './inicio-ses.page';

const routes: Routes = [
  {
    path: '',
    component: InicioSesPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InicioSesPageRoutingModule {}
