import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { RecuperarContraPageRoutingModule } from './recuperar-contra-routing.module';
import { RecuperarContraPage } from './recuperar-contra.page';
import { HttpClientModule } from '@angular/common/http'; 

@NgModule({
  imports: [
    CommonModule,
    FormsModule, // Asegúrate de incluirlo aquí
    IonicModule,
    RecuperarContraPageRoutingModule,
    HttpClientModule // Necesario para las peticiones HTTP
  ],
  declarations: [RecuperarContraPage]
})
export class RecuperarContraPageModule {}
