import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-recuperar-contra',
  templateUrl: './recuperar-contra.page.html',
  styleUrls: ['./recuperar-contra.page.scss'],
})
export class RecuperarContraPage {
  email: string = ''; // Correo ingresado por el usuario

  constructor(private http: HttpClient) {}

  solicitarToken() {
    const url = 'http://localhost:3000/usuarios'; // URL de tu JSON
    this.http.get<any[]>(url).subscribe(
      (usuarios) => {
        // Verificar si el correo existe
        const usuario = usuarios.find((u) => u.email === this.email);
        if (usuario) {
          // Generar un token único
          const token = Math.random().toString(36).substring(2, 8);
          console.log('Token generado (simulado):', token);

          // Simular guardar el token en el servidor (en este caso, localmente)
          usuario.resetToken = token;
          alert('Se ha enviado un token de recuperación a tu correo.');
        } else {
          alert('El correo no está registrado.');
        }
      },
      (error) => {
        console.error('Error al solicitar el token:', error);
      }
    );
  }
}
