import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';

import { Router } from '@angular/router';

@Component({
  selector: 'app-justificacion',
  templateUrl: './justificacion.page.html',
  styleUrls: ['./justificacion.page.scss'],
})
export class JustificacionPage implements OnInit {
  usuarios: any[] = [];
  profesores: any[] = [];
  motivo: string = '';
  idUsuario: string = '';
  idProfesor: string = '';
  idAsignatura: string = '';
  justificacionAgregada: boolean = false;
 
  constructor(private dataService: DataService, private router: Router) {}

  ngOnInit() {
    this.cargarUsuarios();
    this.cargarProfesores();
  }

  async cargarUsuarios() {
    this.usuarios = await this.dataService.getUsuarios();
    console.log('Usuarios cargados:', this.usuarios);
  }


  async cargarProfesores() {
    this.profesores = await this.dataService.getProfesores();
    console.log('Profesores cargados:', this.profesores);
  }

 


  async agregarJustificacion() {
    try {
      if (this.motivo && this.idUsuario && this.idProfesor && this.idAsignatura) {

        await this.dataService.agregarJustificacion(
          this.idUsuario,
          this.idProfesor,
          this.idAsignatura,
          this.motivo
        );

        this.justificacionAgregada = true;

        this.motivo = '';
        this.idUsuario = '';
        this.idProfesor = '';
        this.idAsignatura = '';
      }
    } catch (error) {
      console.error('Error al agregar la justificación:', error);
    }
  }
}
