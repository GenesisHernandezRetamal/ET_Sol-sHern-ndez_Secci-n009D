import { Component, OnInit } from '@angular/core';
import { JustiService } from 'src/app/services/justi.service';

@Component({
  selector: 'app-ver-justificaciones',
  templateUrl: './ver-justificaciones.page.html',
  styleUrls: ['./ver-justificaciones.page.scss'],
})
export class VerJustificacionesPage implements OnInit {
  justificaciones: any[] = [];

  constructor(private justiService: JustiService) {}

  ngOnInit() {
    this.cargarJustificaciones();
  }

  async cargarJustificaciones() {
    try {
      console.log('Cargando justificaciones de usuarios...');
      this.justificaciones = await this.justiService.getJustificacionesUsuarios();
      console.log('Justificaciones cargadas:', this.justificaciones);
    } catch (error) {
      console.error('Error al cargar las justificaciones:', error);
    }
  }
}
