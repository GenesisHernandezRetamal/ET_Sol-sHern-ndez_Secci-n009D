import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { ApidatosService } from 'src/app/services/apidatos.service';
import { ApiusersService } from 'src/app/services/apiusers.service';


@Component({
  selector: 'app-detalle',
  templateUrl: './detalle.page.html',
  styleUrls: ['./detalle.page.scss'],
})
export class DetallePage implements OnInit {

  asignatura: any; 
  currentDate: Date;

  qrdata: string;

  usuarios = {
    id: 0,
    username: "",
    password: "",
    email: "",
    rut: "",
  };

  constructor(
    private ruta: ActivatedRoute,
     private router: Router,
     private alertcontroller: AlertController,
    private apiusers: ApiusersService,
     private apidatos: ApidatosService
  ) {

    this.ruta.queryParams.subscribe(params => {
      this.asignatura = JSON.parse(params['post']);
    });

       this.currentDate = new Date(); 
    this.qrdata = '';
  }

  ngOnInit() {

    console.log('Datos de asignatura:', this.asignatura); 
  }

      generarQr() {
    this.qrdata = `${this.asignatura.nombre} ${this.asignatura.profesor} ${this.usuarios.email} ${this.usuarios.rut}`;
    console.log(this.qrdata);
  }

      regresar() {
        this.router.navigate(['/asignaturas']);
      }
    }
