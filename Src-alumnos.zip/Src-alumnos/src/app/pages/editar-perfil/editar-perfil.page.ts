import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-editar-perfil',
  templateUrl: './editar-perfil.page.html',
  styleUrls: ['./editar-perfil.page.scss'],
})
export class EditarPerfilPage {
  usuario: any = {}; // Usuario a editar
  usuarios: any[] = []; // Lista de usuarios cargada desde el archivo JSON
  showEditForm: boolean = false; // Control para mostrar el formulario de edición
  email: string = ''; // Correo del usuario (para buscarlo)
  usuarioId: string = ''; // ID del usuario a editar
  newPassword: string = ''; // Nueva contraseña, si la quieres permitir editar
  newEmail: string = ''; // Nuevo email si es necesario

  constructor(private http: HttpClient, private toastCtrl: ToastController) {}

  async presentToast(message: string, color: string = 'primary') {
    const toast = await this.toastCtrl.create({
      message,
      duration: 3000,
      color,
    });
    toast.present();
  }

  // Cargar usuarios desde el JSON del servidor
  cargarUsuarios() {
    this.http.get('http://localhost:3000/usuarios').subscribe({
      next: (data: any) => {
        console.log('Respuesta recibida:', data); // Verifica todo el objeto de respuesta
  
        // Asignar directamente el arreglo de usuarios
        this.usuarios = data || [];
        console.log('Datos cargados:', this.usuarios); // Verifica que los datos sean correctos
      },
      error: (err) => {
        console.error('Error al cargar usuarios:', err);
        this.presentToast('Error al cargar los datos. Inténtalo de nuevo.', 'danger');
        this.usuarios = []; // Asegúrate de que `usuarios` sea un arreglo vacío en caso de error
      },
    });
  }


  onSubmit() {

    if (!this.usuarios || this.usuarios.length === 0) {
      this.presentToast('Los datos aún no se han cargado. Intenta más tarde.', 'danger');
      return;
    }
    console.log('Correo ingresado:', this.email); 
    console.log('Usuarios cargados:', this.usuarios);

   
    const user = this.usuarios.find((u) => u.email.toLowerCase() === this.email.toLowerCase()); 

    if (user) {
      console.log('Usuario encontrado:', user); 
      this.presentToast('Correo encontrado. Ahora puedes editar tu perfil.');
      this.usuario = { ...user }; 
      this.showEditForm = true; 
    } else {
      console.log('Correo no encontrado');
      this.presentToast('Correo no encontrado.', 'danger');
    }
  }


  guardarCambios() {
    if (!this.usuario.username || !this.usuario.email || !this.usuario.rut) {
      this.presentToast('Por favor, completa todos los campos obligatorios.', 'danger');
      return;
    }

    this.http.put(`http://localhost:3000/usuarios/${this.usuario.id}`, this.usuario).subscribe({
      next: (response) => {
        console.log('Usuario actualizado en el servidor:', response);
        this.presentToast('Perfil actualizado exitosamente.', 'success');
      },
      error: (err) => {
        console.error('Error al actualizar el perfil:', err);
        this.presentToast('Error al actualizar el perfil en el servidor.', 'danger');
      }
    });

    this.showEditForm = false;
    this.email = '';
    
  }

  // Carga los usuarios al iniciar la página
  ionViewDidEnter() {
    this.cargarUsuarios();
  }
}