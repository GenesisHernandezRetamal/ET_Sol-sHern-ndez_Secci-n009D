import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { Router } from '@angular/router';
import Swiper from 'swiper';
import { AuthserviceService } from 'src/app/services/auth.service';


@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss'],
})
export class InicioPage implements OnInit {
  
  @ViewChild('swiper')
  swiperRef: ElementRef |undefined;
  swiper?: Swiper;

  userName: string | null = null;
  isLoggedIn: boolean = false;

  constructor(private menuController: MenuController, private router: Router,
              private authservice: AuthserviceService
  ) { }
  
  swiperReady(){

    this.swiper=this.swiperRef?.nativeElement.swiper;
  }

  goNext(){
    this.swiper?.slideNext();

  }

  goPrev(){
    this.swiper?.slidePrev();
  }
    
  swiperSlideChanged(e: any){
    console.log('changed: ', e);
  }

  
  ngOnInit() {

  this.userName = sessionStorage.getItem('username'); 
    
  }
  
  mostrarMenu(){
    this.menuController.open('first');
  }

  cerrarMenu() {
    this.menuController.close('first')
  }
  logout() {
    this.authservice.logout();
  }

}



