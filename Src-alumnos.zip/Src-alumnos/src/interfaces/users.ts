
export interface Users {
  id: string;
  username: string;
  password: string;
  email: string;
  rut: string;
  isactive: boolean;
  justificaciones: any[]; 
  clasesRegistradas: any[]; 
}

export interface UserNuevo {
    id: string;
    username: string;
    password: string;
    email: string;
    rut: string;
    isactive: boolean;
    justificaciones: any[]; 
    clasesRegistradas: any[];
  }
  
  export interface Justificacion {
    idJustificacion: number;
    idUsuario: string;
    idProfesor: string;
    asignatura: {
      idAsignatura: string;
      nombre: string;
      fecha: string;
      profesor: string;
      qrData: string;
    };
    fecha: string;
    motivo: string;
    comentarioDocente: string;
  }
  
  export interface Usuario {
    id: string;
    username?: string;
    password?: string;
    email: string;
    rut?: string;
    isactive?: boolean;
    justificaciones: Justificacion[];
    clasesRegistradas: any[];
  }
  
  export interface Profesor {
    id: string;
    username?: string;
    password?: string;
    email: string;
    rut?: string;
    isactive?: boolean;
    fotitoUrl?: string;
    perfil?: {
      titulo: string;
      descripcion: string;
      foto: string;
    };
    justificaciones: Justificacion[]; 
    asignaturas: Asignatura[];
  }
  
  export interface Asignatura {
    idAsignatura: string;
    nombre: string;
    fecha: string;
    profesor: string;
    qrData: string;
  }


