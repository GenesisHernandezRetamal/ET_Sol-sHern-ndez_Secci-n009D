import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { Router } from '@angular/router';
import Swiper from 'swiper';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss'],
})
export class InicioPage implements OnInit {

  @ViewChild('swiper')
  swiperRef: ElementRef |undefined;
  swiper?: Swiper;
  

  username: string = '';
  isLoggedIn: boolean = false;

  constructor(private menuController: MenuController, private router: Router) { }

  ngOnInit() {
    
    const storedUsername = sessionStorage.getItem('docenteUsername');
    console.log('Usuario almacenado:', storedUsername); 
    if (storedUsername) {
      this.username = storedUsername;
      this.isLoggedIn = true;
    } else {
      this.isLoggedIn = false;
    }

  }

  swiperReady(){

    this.swiper=this.swiperRef?.nativeElement.swiper;
  }

  goNext(){
    this.swiper?.slideNext();

  }

  goPrev(){
    this.swiper?.slidePrev();
  }
    
  swiperSlideChanged(e: any){
    console.log('changed: ', e);
  }

  mostrarMenu() {
    this.menuController.open('first');
  }

  cerrarMenu() {
    this.menuController.close('first');
  }

  logout() {
   
    sessionStorage.removeItem('docenteUsername');
    sessionStorage.removeItem('docenteId');
    this.router.navigate(['/inicio']).then(() => {
      location.reload(); 
    });
  }

  
  afterLogin() {
    
    const storedUsername = sessionStorage.getItem('docenteUsername');
    if (storedUsername) {
      this.username = storedUsername;
      this.isLoggedIn = true;
      location.reload(); 
    }
  }
}
