import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-justificaciones',
  templateUrl: './justificaciones.page.html',
  styleUrls: ['./justificaciones.page.scss'],
})
export class JustificacionesPage implements OnInit {
  justificaciones: any[] = []; 

  constructor(private dataService: DataService) {}

  ngOnInit() {
    this.cargarJustificaciones();
  }


  async cargarJustificaciones() {
    try {
      this.justificaciones = await this.dataService.obtenerJustificaciones();
    } catch (error) {
      console.error('Error al cargar justificaciones:', error);
    }
  }

  async guardarComentario(justificacion: any) {
    try {
      if (justificacion.comentarioDocente) {
        await this.dataService.actualizarComentarioJustificacion(
          justificacion.idJustificacion,
          justificacion.comentarioDocente
        );
        console.log('Comentario guardado:', justificacion.comentarioDocente);
        alert('Comentario guardado correctamente.');
      } else {
        alert('El comentario está vacío.');
      }
    } catch (error) {
      console.error('Error al guardar comentario:', error);
      alert('Error al guardar el comentario.');
    }
  }
}