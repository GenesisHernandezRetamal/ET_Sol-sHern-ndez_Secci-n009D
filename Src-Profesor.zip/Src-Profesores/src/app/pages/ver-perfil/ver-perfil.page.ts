

import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DocenteNuevo } from 'src/interfaces/docente';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ver-perfil',
  templateUrl: './ver-perfil.page.html',
  styleUrls: ['./ver-perfil.page.scss'],
})
export class VerPerfilPage implements OnInit {
  perfilForm: FormGroup;
  docente: DocenteNuevo | undefined;

  constructor(
    private authService: AuthService,
    private fb: FormBuilder,
    private router: Router
  ) {
    this.perfilForm = this.fb.group({
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      rut: ['', Validators.required],
      titulo: ['', Validators.required],
      descripcion: ['', Validators.required],
    });
  }

  ngOnInit() {
    this.cargarPerfil();
  }

  cargarPerfil() {
    const username = sessionStorage.getItem('docenteUsername');
    if (username) {
      this.authService.GetDocenteByUsername(username).subscribe((response) => {
        this.docente = response[0];
        if (this.docente) {
          this.perfilForm.patchValue({
            username: this.docente.username,
            email: this.docente.email,
            rut: this.docente.rut,
            titulo: this.docente.perfil.titulo,
            descripcion: this.docente.perfil.descripcion,
          });
        }
      });
    }
  }

  guardarPerfil() {
    if (this.perfilForm.valid && this.docente) {
      const perfilActualizado: DocenteNuevo = {
        ...this.docente,
        username: this.perfilForm.value.username,
        email: this.perfilForm.value.email,
        rut: this.perfilForm.value.rut,
        perfil: {
          titulo: this.perfilForm.value.titulo,
          descripcion: this.perfilForm.value.descripcion,
          foto: this.docente.perfil.foto,
        },
      };

      
    }
  }
}
