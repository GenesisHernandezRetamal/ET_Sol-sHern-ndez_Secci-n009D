import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class DataService {
  private usuariosPath = 'http://localhost:3000/usuarios';
  private profesoresPath = 'http://localhost:3000/profes';

  constructor(private http: HttpClient) {}

  async obtenerJustificaciones(): Promise<any[]> {
    try {
      const usuarios: any[] = (await this.http.get<any[]>(this.usuariosPath).toPromise()) || [];
      const justificaciones = usuarios.reduce((acumulador, usuario) => {
        return acumulador.concat(usuario.justificaciones || []);
      }, []);
      return justificaciones;
    } catch (error) {
      console.error('Error al obtener las justificaciones:', error);
      throw error;
    }
  }

  async actualizarComentarioJustificacion(
    idJustificacion: number,
    comentario: string
  ): Promise<void> {
    try {
      const usuarios: any[] = (await this.http.get<any[]>(this.usuariosPath).toPromise()) || [];
      const profesores: any[] = (await this.http.get<any[]>(this.profesoresPath).toPromise()) || [];

      usuarios.forEach((usuario) => {
        const justificacion = usuario.justificaciones?.find(
          (j: any) => j.idJustificacion === idJustificacion
        );
        if (justificacion) {
          justificacion.comentarioDocente = comentario;
        }
      });

      profesores.forEach((profes) => {
        const justificacion = profes.justificaciones?.find(
          (j: any) => j.idJustificacion === idJustificacion
        );
        if (justificacion) {
          justificacion.comentarioDocente = comentario;
        }
      });

      for (const usuario of usuarios) {
        await this.http.put(`${this.usuariosPath}/${usuario.id}`, usuario).toPromise();
      }
  
      for (const profesor of profesores) {
        await this.http.put(`${this.profesoresPath}/${profesor.id}`, profesor).toPromise();
      }
  
      console.log('Comentario actualizado correctamente');
    } catch (error) {
      console.error('Error al actualizar el comentario:', error);
      throw error;
    }
  }
  

  
}