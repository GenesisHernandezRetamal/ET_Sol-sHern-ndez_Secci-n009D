import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Docente, DocenteNuevo } from 'src/interfaces/docente';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { Users, UserNuevo } from 'src/interfaces/users';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private loggedInUser: any = null;
  private currentUser: any;
  private apiUrl2 = 'http://localhost:3000/usuarios';
  private usuarioId: string;
  private apiUrl = 'http://localhost:3000';

  constructor(private httpclient: HttpClient) {
 
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') || 'null');
    this.usuarioId = localStorage.getItem('usuarioId') || ''; 
  }
 
  GetDocenteByUsername(username: string): Observable<Docente[]> {
    return this.httpclient.get<Docente[]>(`${environment.urlApi}profes/?username=${username}`);
  }

  GetUserByUsername(username: string): Observable<UserNuevo[]> {
    return this.httpclient.get<UserNuevo[]>(`${environment.urlApi}usuarios/?username=${username}`);
  }

 
  logout() {
    sessionStorage.removeItem('username');
    this.currentUser = null;
    this.usuarioId = '';  
  }
 
  PostProfesor(profesorNuevo: DocenteNuevo): Observable<DocenteNuevo> {
    return this.httpclient.post<DocenteNuevo>(`${environment.urlApi}profes`, profesorNuevo);
  }

  PostUsuario(nuevoUsuario: UserNuevo): Observable<UserNuevo> {
    return this.httpclient.post<UserNuevo>(`${environment.urlApi}usuarios`, nuevoUsuario);
  }
 
  actualizarDocente(docente: DocenteNuevo): Observable<DocenteNuevo> {
    return this.httpclient.put<DocenteNuevo>(`${environment.urlApi}profes/${docente.username}`, docente);
  }
 
  getCurrentUser() {
    return this.currentUser;
  }
  getLoggedInUser() {
    return this.loggedInUser;  
  }
 
  login(user: any) {
    this.loggedInUser = user;
  }
 
  getUsuarioId() {
    return localStorage.getItem('usuarioId');
  }
 
  obtenerJustificacionesPorProfesor(idProfesor: string): Observable<any[]> {
    return this.httpclient.get<any>(`http://localhost:3000/profes/${idProfesor}`).pipe(
      map((profesor) => {
        console.log('Profesor:', profesor); 
        return profesor.justificaciones || [];  
      })
    );
  }

  actualizarJustificacion(idUsuario: string, idJustificacion: number, comentario: string): Observable<any> {
    const url = `${this.apiUrl2}/${idUsuario}/justificaciones/${idJustificacion}`;
    const body = { comentarioDocente: comentario }; 
    console.log('Enviando PUT a:', url, 'con body:', body); 
    return this.httpclient.put(url, body);
  }
  setUsuarioId(usuarioId: string) {
    localStorage.setItem('usuarioId', usuarioId);
  }
  
  login1(user: any) {
    this.loggedInUser = user;
  }
 
  getLoggedInUser2() {
    return this.loggedInUser;
  }

 
  isLoggedIn() {
    return this.loggedInUser !== null;
  }

}
