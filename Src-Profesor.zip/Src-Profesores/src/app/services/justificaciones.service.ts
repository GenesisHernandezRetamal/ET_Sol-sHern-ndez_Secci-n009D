import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { ApiusersService } from './apiusers.service';

@Injectable({
  providedIn: 'root'
})
export class JustificacionesService {
  private justificaciones = [
    {
      idJustificacion: 1732223427743,
      idUsuario: "2",
      idProfesor: "1",
      asignatura: "Arquitectura",
      fecha: "2024-11-21T21:10:27.743Z",
      motivo: "toi comiendo completos",
      comentarioDocente: ""
    },

  ];

  constructor(private http: HttpClient) {}

  obtenerJustificaciones(): Observable<any[]> {
    return of(this.justificaciones); 
  }




  guardarComentario(justificacion: any): Observable<any> {
    const url = 'http://localhost:3000/profes/justificaciones';

    return this.http.post(url, justificacion);
  }
}