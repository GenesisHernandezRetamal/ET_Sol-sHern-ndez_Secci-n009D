import { Component } from '@angular/core';
import { RedirectCommand } from '@angular/router';
import { MenuController } from '@ionic/angular';
import {register} from 'swiper/element/bundle';
register();

interface Opciones{
  icon:string;
  name:string;
  redirecTo: string;
}


@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  opciones: Opciones[]=[
    {
      icon: 'person-outline',
      name: 'Iniciar Sesión',
      redirecTo: '/iniciar-sesion'
    },
    {
      icon: 'person-add-outline',
      name: 'Registro',
      redirecTo: '/registro'
    },
    {
      icon: 'person-circle-outline',
      name: 'Ver Perfil',
      redirecTo: '/ver-perfil'
    },
    {
      icon: 'reader-outline',
      name: 'Justificaciones',
      redirecTo: '/justificaciones'
    },
    {
      icon: 'camera-outline',
      name: 'Camara',
      redirecTo:'/escanear'
    }
    

  ]
  

  constructor(private menuController: MenuController) { }
  cerrarMenu() {
    this.menuController.close('first')
  }
  }
