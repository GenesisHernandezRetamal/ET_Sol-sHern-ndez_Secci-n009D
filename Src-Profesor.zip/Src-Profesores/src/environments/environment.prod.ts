export const environment = {
  production: true,
  //urlApi:'http://localhost:3000/'
  urlApi: 'https://datacosas.onrender.com/'
  
};
